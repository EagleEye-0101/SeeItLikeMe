import SwiftUI

struct ContentView: View {
    @StateObject private var store = AppStore()
    
    private var isImmersed: Bool {
        if case .journey = store.flow { return true }
        return false
    }
    
    var body: some View {
        ZStack {
            ZStack {
                if store.flow == .onboarding {
                    AmbientBackground()
                    OnboardingView()
                        .transition(.opacity.combined(with: .scale(scale: 1.05)))
                } else {
                    HubView()
                        .opacity(isImmersed ? 0.2 : 1.0)
                        .blur(radius: isImmersed ? 20 : 0)
                        .scaleEffect(isImmersed ? 1.05 : 1.0)
                        .animation(.easeInOut(duration: 1.2), value: isImmersed)
                    
                    if case .journey(let kind) = store.flow {
                        ExperienceJourneyWrapper(kind: kind)
                            .transition(.opacity.combined(with: .move(edge: .bottom)))
                            .zIndex(1)
                    }
                    
                    if store.flow == .synthesis {
                        SynthesisView()
                            .transition(.opacity)
                            .zIndex(2)
                    }
                }
            }
            .animation(.easeInOut(duration: 1.0), value: store.flow)
            
            if store.flow != .onboarding {
                VStack {
                    Spacer()
                    BottomDock()
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .ignoresSafeArea(.keyboard)
                .animation(.spring(response: 0.6, dampingFraction: 0.85), value: store.flow)
            }
        }
        .environmentObject(store)
        .preferredColorScheme(.dark)
    }
}
