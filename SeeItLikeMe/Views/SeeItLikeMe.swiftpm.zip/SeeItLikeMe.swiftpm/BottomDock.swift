import SwiftUI

struct BottomDock: View {
    @EnvironmentObject var store: AppStore
    
    var body: some View {
        HStack(spacing: 20) {
            // 1. Context indicator
            HStack(spacing: 6) {
                Image(systemName: contextIcon)
                    .font(.caption)
                Text(contextLabel)
                    .font(.caption2.weight(.medium))
            }
            .foregroundColor(.white.opacity(0.4))
            .frame(maxWidth: .infinity, alignment: .leading)
            
            // 2. Progress (visual only)
            HStack(spacing: 3) {
                ForEach(0..<ExperienceKind.allCases.count, id: \.self) { i in
                    Circle()
                        .fill(Color.white.opacity(i < store.completedExperiences.count ? 0.6 : 0.1))
                        .frame(width: 4, height: 4)
                }
            }
            
            // 3. Reflect
            Button(action: {
                if case .integrating(let kind) = store.hubState {
                    store.finishJourney(kind)
                }
            }) {
                Text("Reflect")
                    .font(.caption.weight(.medium))
                    .foregroundColor(.white.opacity(reflectEnabled ? 0.8 : 0.15))
                    .padding(.horizontal, 14)
                    .padding(.vertical, 6)
                    .background(
                        Capsule()
                            .fill(Color.white.opacity(reflectEnabled ? 0.08 : 0.03))
                    )
            }
            .disabled(!reflectEnabled)
            
            // 4. Shift Perspective
            Image(systemName: "circle.hexagongrid")
                .font(.caption)
                .foregroundColor(.white.opacity(0.3))
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(
            Capsule()
                .fill(.ultraThinMaterial)
                .opacity(0.8)
        )
        .padding(.horizontal, 24)
        .padding(.bottom, 16)
    }
    
    private var contextIcon: String {
        switch store.flow {
        case .hub: return "circle.grid.2x2"
        case .journey(let kind): return kind.icon
        case .synthesis: return "sparkles"
        default: return "circle"
        }
    }
    
    private var contextLabel: String {
        switch store.flow {
        case .hub: return "Hub"
        case .journey(let kind): return kind.rawValue
        case .synthesis: return "Synthesis"
        default: return ""
        }
    }
    
    private var reflectEnabled: Bool {
        if case .integrating = store.hubState { return true }
        return false
    }
}
