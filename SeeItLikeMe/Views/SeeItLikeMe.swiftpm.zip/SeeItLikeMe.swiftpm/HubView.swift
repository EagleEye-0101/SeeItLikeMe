import SwiftUI

// MARK: - Hub View (Three-Zone Layout)

struct HubView: View {
    @EnvironmentObject var store: AppStore
    @State private var selectedKind: ExperienceKind? = nil
    
    var body: some View {
        ZStack {
            // ── ZONE 1: BACKGROUND ──
            // Pure atmosphere. No icons, no text, no interaction.
            HubBackground(progress: completionRatio)
            
            // ── ZONE 2: CENTER ──
            // The only place experience nodes exist.
            GeometryReader { geo in
                let fieldCenter = CGPoint(
                    x: geo.size.width / 2,
                    y: geo.size.height * 0.44
                )
                let fieldRadius = min(geo.size.width, geo.size.height) * 0.32
                
                ForEach(Array(ExperienceKind.allCases.enumerated()), id: \.element.id) { index, kind in
                    ExperienceNode(
                        kind: kind,
                        isSelected: selectedKind == kind,
                        isAnySelected: selectedKind != nil
                    )
                    .position(
                        nodePosition(
                            index: index,
                            total: ExperienceKind.allCases.count,
                            radius: fieldRadius,
                            center: fieldCenter
                        )
                    )
                    .onTapGesture {
                        if selectedKind == kind {
                            store.beginJourney(kind)
                        } else {
                            withAnimation(.easeInOut(duration: 0.35)) {
                                selectedKind = kind
                            }
                        }
                    }
                }
            }
            
            // ── ZONE 3: BOTTOM ──
            // Managed entirely by ContentView's BottomDock.
            // Nothing else lives here.
        }
        .ignoresSafeArea()
    }
    
    // MARK: - Layout
    
    private var completionRatio: Double {
        Double(store.completedExperiences.count) / Double(max(ExperienceKind.allCases.count, 1))
    }
    
    /// Even elliptical placement around the field center.
    private func nodePosition(index: Int, total: Int, radius: CGFloat, center: CGPoint) -> CGPoint {
        let angle = (CGFloat(index) / CGFloat(total)) * 2 * .pi - .pi / 2
        return CGPoint(
            x: center.x + Foundation.cos(angle) * radius,
            y: center.y + Foundation.sin(angle) * radius * 1.15
        )
    }
}

// MARK: - Zone 1: Background

private struct HubBackground: View {
    let progress: Double
    @State private var drift = false
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            RadialGradient(
                colors: [
                    Color.indigo.opacity(0.12 + progress * 0.06),
                    Color.black
                ],
                center: drift ? UnitPoint(x: 0.35, y: 0.3) : UnitPoint(x: 0.65, y: 0.7),
                startRadius: 80,
                endRadius: 900
            )
            .ignoresSafeArea()
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 25).repeatForever(autoreverses: true)) {
                drift = true
            }
        }
    }
}

// MARK: - Zone 2: Experience Node

struct ExperienceNode: View {
    let kind: ExperienceKind
    let isSelected: Bool
    let isAnySelected: Bool
    @EnvironmentObject var store: AppStore
    
    private var isCompleted: Bool { store.completedExperiences.contains(kind) }
    
    // Dimmed when another node is selected
    private var dimmed: Bool { isAnySelected && !isSelected }
    
    var body: some View {
        VStack(spacing: 10) {
            ZStack {
                // Ring
                Circle()
                    .stroke(ringColor, lineWidth: isSelected ? 1.5 : 1)
                    .frame(width: 60, height: 60)
                
                // Fill
                Circle()
                    .fill(.ultraThinMaterial)
                    .opacity(isSelected ? 0.25 : (isCompleted ? 0.15 : 0.04))
                    .frame(width: 60, height: 60)
                
                // Icon
                Image(systemName: kind.icon)
                    .font(.system(size: 20, weight: .light))
                    .foregroundColor(iconColor)
            }
            .scaleEffect(isSelected ? 1.12 : (dimmed ? 0.92 : 1.0))
            .shadow(color: .white.opacity(isSelected ? 0.1 : 0), radius: 16)
            .animation(.easeInOut(duration: 0.3), value: isSelected)
            .animation(.easeInOut(duration: 0.3), value: dimmed)
            
            // Label anchored directly to node
            Text(kind.rawValue)
                .font(.system(size: 9, weight: .medium, design: .rounded))
                .foregroundColor(.white.opacity(labelOpacity))
                .lineLimit(1)
                .animation(.easeInOut(duration: 0.3), value: isSelected)
        }
        .opacity(dimmed ? 0.4 : 1.0)
        .animation(.easeInOut(duration: 0.3), value: dimmed)
    }
    
    private var ringColor: Color {
        if isSelected { return .white.opacity(0.5) }
        if isCompleted { return .white.opacity(0.35) }
        return .white.opacity(0.1)
    }
    
    private var iconColor: Color {
        if isSelected { return .white }
        if isCompleted { return .white.opacity(0.7) }
        return .white.opacity(0.35)
    }
    
    private var labelOpacity: Double {
        if isSelected { return 0.6 }
        if isCompleted { return 0.3 }
        return 0.15
    }
}