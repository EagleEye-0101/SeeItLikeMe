See It Like Me - Swift Playgrounds App

A WWDC-style experience exploring how interface design affects accessibility, focus, comfort, and well-being.

Built with SwiftUI for the Apple Swift Student Challenge.