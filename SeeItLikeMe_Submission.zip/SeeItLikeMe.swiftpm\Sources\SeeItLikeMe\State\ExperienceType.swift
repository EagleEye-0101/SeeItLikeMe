import Foundation

enum ExperienceType: CaseIterable, Identifiable {
    case visualStrain
    case readingStability
    case focusDistraction
    case interactionPrecision
    case focusTunnel
    case colorPerception
    
    var id: String { rawValue }
    
    var title: String {
        switch self {
        case .visualStrain: return "Visual Strain"
        case .readingStability: return "Reading Stability"
        case .focusDistraction: return "Focus & Distraction"
        case .interactionPrecision: return "Interaction Precision"
        case .focusTunnel: return "Focus Tunnel"
        case .colorPerception: return "Color Perception"
        }
    }
    
    var subtitle: String {
        switch self {
        case .visualStrain: return "Small text, low contrast"
        case .readingStability: return "Moving content, flickering"
        case .focusDistraction: return "Busy layouts, interruptions"
        case .interactionPrecision: return "Tiny targets, complex gestures"
        case .focusTunnel: return "Narrow attention, tunnel vision"
        case .colorPerception: return "Color-dependent information"
        }
    }
    
    var icon: String {
        switch self {
        case .visualStrain: return "eye"
        case .readingStability: return "text.alignleft"
        case .focusDistraction: return "brain.head.profile"
        case .interactionPrecision: return "hand.tap"
        case .focusTunnel: return "circle.righthalf.filled"
        case .colorPerception: return "eyedropper"
        }
    }
}