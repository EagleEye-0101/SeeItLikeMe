import SwiftUI

struct ExperienceIntroView: View {
    let experience: ExperienceType
    let onStart: () -> Void
    
    var body: some View {
        VStack(spacing: 32) {
            Spacer()
            
            Image(systemName: experience.icon)
                .font(.system(size: 80, weight: .thin))
                .foregroundStyle(.primary)
            
            VStack(spacing: 16) {
                Text(experience.title)
                    .font(.largeTitle.weight(.semibold))
                    .foregroundStyle(.primary)
                
                Text(experience.subtitle)
                    .font(.title3)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            
            Spacer()
            
            PrimaryButton(title: "Start Experience", action: onStart)
                .padding(.bottom)
        }
        .padding()
    }
}