import SwiftUI

struct ContentView: View {
    @State private var appPhase: AppPhase = .intro
    @State private var currentExperience: ExperienceType?
    @State private var experienceStep: ExperienceStep = .intro
    
    var body: some View {
        VStack {
            switch appPhase {
            case .intro:
                AppIntroView(onStart: {
                    withAnimation(.smooth(duration: 0.5)) {
                        appPhase = .selection
                    }
                })
                
            case .selection:
                SelectionView(
                    onExperienceSelected: { experience in
                        currentExperience = experience
                        experienceStep = .intro
                        withAnimation(.smooth(duration: 0.5)) {
                            appPhase = .experience
                        }
                    },
                    onFinalReflection: {
                        withAnimation(.smooth(duration: 0.5)) {
                            appPhase = .finalReflection
                        }
                    }
                )
                
            case .experience:
                if let experience = currentExperience {
                    ExperienceContainerView(
                        experience: experience,
                        step: $experienceStep,
                        onExit: {
                            withAnimation(.smooth(duration: 0.5)) {
                                appPhase = .selection
                                currentExperience = nil
                            }
                        }
                    )
                }
                
            case .finalReflection:
                FinalReflectionView(
                    onRestart: {
                        withAnimation(.smooth(duration: 0.5)) {
                            appPhase = .intro
                        }
                    }
                )
            }
        }
        .animation(.smooth(duration: 0.3), value: appPhase)
    }
}