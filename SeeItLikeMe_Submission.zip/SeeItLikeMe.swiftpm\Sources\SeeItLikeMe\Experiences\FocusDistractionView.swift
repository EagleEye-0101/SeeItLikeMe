import SwiftUI

struct FocusDistractionView: View {
    let onComplete: () -> Void
    @State private var distractions: [Distraction] = []
    @State private var focusCount = 0
    @State private var timerProgress: CGFloat = 0
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Focus & Distraction")
                .font(.largeTitle.weight(.semibold))
                .foregroundStyle(.primary)
            
            Text("Count the blue circles while distractions appear")
                .font(.title2)
                .foregroundStyle(.secondary)
               
            
            ZStack {
                // Focus task
                Text("\(focusCount)")
                    .font(.largeTitle.weight(.bold))
                    .foregroundStyle(.blue)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                
                // Distractions
                ForEach(distractions) { distraction in
                    Circle()
                        .fill(distraction.color)
                        .frame(width: 30, height: 30)
                        .position(distraction.position)
                        .transition(.scale)
                }
            }
            .frame(height: 300)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(16)
            
            VStack(spacing: 16) {
                Button(action: {
                    withAnimation(.spring(response: 0.3)) {
                        focusCount += 1
                    }
                }) {
                    Text("Count Blue Circle")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(12)
                }
                
                Text("Tap while distractions appear around the screen")
                    .font(.callout)
                    .foregroundStyle(.tertiary)
                    .multilineTextAlignment(.center)
            }
            .padding()
            
            Spacer()
            
            ProgressView(value: timerProgress, total: 1.0)
                .progressViewStyle(LinearProgressViewStyle())
                .padding(.horizontal)
            
            PrimaryButton(title: "Continue", action: onComplete)
                .padding(.bottom)
        }
        .padding()
        .onAppear {
            startDistractions()
            startTimer()
        }
        .onDisappear {
            timerProgress = 0
        }
    }
    
    private func startDistractions() {
        Timer.scheduledTimer(withTimeInterval: 0.8, repeats: true) { timer in
            guard timerProgress < 1.0 else {
                timer.invalidate()
                return
            }
            
            let colors: [Color] = [.red, .green, .orange, .purple, .pink]
            let randomColor = colors.randomElement()!
            
            let position = CGPoint(
                x: CGFloat.random(in: 50...UIScreen.main.bounds.width - 100),
                y: CGFloat.random(in: 200...400)
            )
            
            let distraction = Distraction(id: UUID(), color: randomColor, position: position)
            
            withAnimation(.spring(response: 0.5)) {
                distractions.append(distraction)
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                withAnimation(.spring(response: 0.3)) {
                    distractions.removeAll { $0.id == distraction.id }
                }
            }
        }
    }
    
    private func startTimer() {
        Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { timer in
            guard timerProgress < 1.0 else {
                timer.invalidate()
                return
            }
            timerProgress += 0.01
        }
    }
}

struct Distraction: Identifiable {
    let id: UUID
    let color: Color
    let position: CGPoint
}