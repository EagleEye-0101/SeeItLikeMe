import SwiftUI

struct AccessibilityHelpers {
    static func isReduceMotionEnabled() -> Bool {
        UIAccessibility.isReduceMotionEnabled
    }
    
    static func isBoldTextEnabled() -> Bool {
        UIAccessibility.isBoldTextEnabled
    }
    
    static func isGrayscaleEnabled() -> Bool {
        UIAccessibility.isGrayscaleEnabled
    }
    
    static func isInvertColorsEnabled() -> Bool {
        UIAccessibility.isInvertColorsEnabled
    }
}