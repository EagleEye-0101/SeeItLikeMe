import SwiftUI

struct VisualStrainView: View {
    let onComplete: () -> Void
    @State private var isActive = false
    @State private var timerProgress: CGFloat = 0
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Visual Strain")
                .font(.largeTitle.weight(.semibold))
                .foregroundStyle(.primary)
            
            Text("Try to read the text below")
                .font(.title2)
                .foregroundStyle(.secondary)
            
            VStack(spacing: 25) {
                // Low contrast small text
                Text("The quick brown fox jumps over the lazy dog. Pack my box with five dozen liquor jugs.")
                    .font(.system(size: 12, weight: .regular))
                    .foregroundStyle(Color.primary.opacity(0.3))
                    .multilineTextAlignment(.center)
                    .padding()
                    .background(Color.clear)
                    .cornerRadius(8)
                
                // Better contrast version (appears on tap)
                if isActive {
                    Text("The quick brown fox jumps over the lazy dog. Pack my box with five dozen liquor jugs.")
                        .font(.body)
                        .foregroundStyle(.primary)
                        .multilineTextAlignment(.center)
                        .padding()
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(8)
                }
            }
            .frame(maxWidth: .infinity)
            .padding()
            
            if !isActive {
                Text("Tap anywhere to reveal clearer text")
                    .font(.callout)
                    .foregroundStyle(.tertiary)
            } else {
                Text("Notice the difference in readability")
                    .font(.callout)
                    .foregroundStyle(.tertiary)
            }
            
            Spacer()
            
            ProgressView(value: timerProgress, total: 1.0)
                .progressViewStyle(LinearProgressViewStyle())
                .padding(.horizontal)
            
            PrimaryButton(
                title: isActive ? "Continue" : "Show Clear Text",
                action: {
                    if !isActive {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            isActive = true
                        }
                    } else {
                        onComplete()
                    }
                }
            )
            .padding(.bottom)
        }
        .padding()
        .onAppear {
            startTimer()
        }
        .onDisappear {
            timerProgress = 0
        }
    }
    
    private func startTimer() {
        Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { timer in
            guard timerProgress < 1.0 else {
                timer.invalidate()
                return
            }
            timerProgress += 0.01
        }
    }
}