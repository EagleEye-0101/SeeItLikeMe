import SwiftUI

struct SelectionView: View {
    let onExperienceSelected: (ExperienceType) -> Void
    let onFinalReflection: () -> Void
    
    var body: some View {
        ScrollView {
            VStack(spacing: 32) {
                SectionHeader(
                    title: "Choose an Experience",
                    subtitle: "Explore how different design choices affect perception and interaction"
                )
                
                LazyVGrid(columns: [
                    GridItem(.flexible()),
                    GridItem(.flexible())
                ], spacing: 20) {
                    ForEach(ExperienceType.allCases) { experience in
                        ExperienceCard(
                            experience: experience,
                            onTap: { onExperienceSelected(experience) }
                        )
                    }
                }
                .padding(.horizontal)
                
                VStack(spacing: 16) {
                    Text("Ready to reflect?")
                        .font(.headline)
                        .foregroundStyle(.primary)
                    
                    PrimaryButton(
                        title: "View Final Reflection",
                        action: onFinalReflection
                    )
                }
                .padding()
            }
            .padding(.vertical)
        }
    }
}