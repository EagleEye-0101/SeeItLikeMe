import Foundation

enum ExperienceStep {
    case intro
    case simulation
    case reflection
}