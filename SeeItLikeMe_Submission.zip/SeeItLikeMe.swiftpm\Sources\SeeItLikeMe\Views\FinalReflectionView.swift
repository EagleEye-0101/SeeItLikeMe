import SwiftUI

struct FinalReflectionView: View {
    let onRestart: () -> Void
    
    var body: some View {
        ScrollView {
            VStack(spacing: 32) {
                Spacer()
                    .frame(height: 40)
                
                Image(systemName: "heart")
                    .font(.system(size: 80, weight: .thin))
                    .foregroundStyle(.primary)
                
                VStack(spacing: 24) {
                    Text("Final Reflection")
                        .font(.largeTitle.weight(.semibold))
                        .foregroundStyle(.primary)
                    
                    Text(finalReflectionText)
                        .font(.body)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                    
                    Text(disclaimerText)
                        .font(.caption)
                        .foregroundStyle(.tertiary)
                        .multilineTextAlignment(.center)
                        .padding()
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(12)
                        .padding(.horizontal)
                }
                
                Spacer()
                
                PrimaryButton(title: "Start Over", action: onRestart)
                    .padding(.bottom)
            }
            .padding()
        }
    }
    
    private var finalReflectionText: String {
        """
        Through these experiences, you've glimpsed how interface design choices affect perception, attention, and interaction.
        
        Thoughtful design considers the full spectrum of human experience—visual comfort, cognitive load, motor precision, and attention patterns.
        
        Every interface decision ripples through the user's experience. Small improvements in accessibility create meaningful differences in how people engage with technology.
        
        Design with empathy. Design for everyone.
        """
    }
    
    private var disclaimerText: String {
        "This experience is for awareness only and does not represent medical advice or diagnosis."
    }
}