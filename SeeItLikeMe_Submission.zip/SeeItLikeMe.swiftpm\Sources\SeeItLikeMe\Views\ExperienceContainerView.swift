import SwiftUI

struct ExperienceContainerView: View {
    let experience: ExperienceType
    @Binding var step: ExperienceStep
    let onExit: () -> Void
    
    var body: some View {
        VStack {
            switch step {
            case .intro:
                ExperienceIntroView(
                    experience: experience,
                    onStart: {
                        withAnimation(.smooth(duration: 0.5)) {
                            step = .simulation
                        }
                    }
                )
                
            case .simulation:
                experience.simulationView(
                    onComplete: {
                        withAnimation(.smooth(duration: 0.5)) {
                            step = .reflection
                        }
                    }
                )
                
            case .reflection:
                ExperienceReflectionView(
                    experience: experience,
                    onExit: onExit
                )
            }
        }
        .animation(.smooth(duration: 0.3), value: step)
    }
}

extension ExperienceType {
    @ViewBuilder
    func simulationView(onComplete: @escaping () -> Void) -> some View {
        switch self {
        case .visualStrain:
            VisualStrainView(onComplete: onComplete)
        case .readingStability:
            ReadingStabilityView(onComplete: onComplete)
        case .focusDistraction:
            FocusDistractionView(onComplete: onComplete)
        case .interactionPrecision:
            InteractionPrecisionView(onComplete: onComplete)
        case .focusTunnel:
            FocusTunnelView(onComplete: onComplete)
        case .colorPerception:
            ColorPerceptionView(onComplete: onComplete)
        }
    }
}