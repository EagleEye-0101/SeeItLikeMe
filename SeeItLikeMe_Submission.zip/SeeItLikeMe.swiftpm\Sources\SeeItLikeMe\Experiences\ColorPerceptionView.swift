import SwiftUI

struct ColorPerceptionView: View {
    let onComplete: () -> Void
    @State private var selectedColors: [UUID: ColorInfo] = [:]
    @State private var timerProgress: CGFloat = 0
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Color Perception")
                .font(.largeTitle.weight(.semibold))
                .foregroundStyle(.primary)
            
            Text("Identify items by color alone")
                .font(.title2)
                .foregroundStyle(.secondary)
            
            VStack(spacing: 25) {
                // Color-only information
                HStack(spacing: 20) {
                    ForEach(colorItems) { item in
                        VStack(spacing: 8) {
                            Circle()
                                .fill(item.color)
                                .frame(width: 50, height: 50)
                            
                            Text(item.name)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                
                Text("Without labels, which is which?")
                    .font(.callout)
                    .foregroundStyle(.tertiary)
                
                // Interactive selection
                VStack(alignment: .leading, spacing: 12) {
                    Text("Select what each color represents:")
                        .font(.headline)
                        .foregroundStyle(.primary)
                    
                    ForEach(colorItems) { item in
                        HStack {
                            Circle()
                                .fill(item.color)
                                .frame(width: 20, height: 20)
                            
                            Picker("", selection: Binding(
                                get: { selectedColors[item.id]?.name ?? "" },
                                set: { newName in
                                    selectedColors[item.id] = ColorInfo(id: item.id, name: newName, color: item.color)
                                }
                            )) {
                                ForEach(item.options, id: \.self) {
                                    Text($0).tag($0)
                                }
                            }
                            .pickerStyle(MenuPickerStyle())
                        }
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(12)
            }
            .padding()
            
            Text("Color vision varies greatly between individuals")
                .font(.callout)
                .foregroundStyle(.tertiary)
                .multilineTextAlignment(.center)
            
            Spacer()
            
            ProgressView(value: timerProgress, total: 1.0)
                .progressViewStyle(LinearProgressViewStyle())
                .padding(.horizontal)
            
            PrimaryButton(title: "Continue", action: onComplete)
                .padding(.bottom)
        }
        .padding()
        .onAppear {
            startTimer()
        }
        .onDisappear {
            timerProgress = 0
        }
    }
    
    private func startTimer() {
        Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { timer in
            guard timerProgress < 1.0 else {
                timer.invalidate()
                return
            }
            timerProgress += 0.01
        }
    }
    
    private let colorItems = [
        ColorItem(
            id: UUID(),
            name: "Error",
            color: Color.red,
            options: ["Error", "Success", "Warning", "Info"]
        ),
        ColorItem(
            id: UUID(),
            name: "Success",
            color: Color.green,
            options: ["Error", "Success", "Warning", "Info"]
        ),
        ColorItem(
            id: UUID(),
            name: "Warning",
            color: Color.orange,
            options: ["Error", "Success", "Warning", "Info"]
        ),
        ColorItem(
            id: UUID(),
            name: "Info",
            color: Color.blue,
            options: ["Error", "Success", "Warning", "Info"]
        )
    ]
}

struct ColorItem: Identifiable {
    let id: UUID
    let name: String
    let color: Color
    let options: [String]
}

struct ColorInfo: Identifiable {
    let id: UUID
    let name: String
    let color: Color
}