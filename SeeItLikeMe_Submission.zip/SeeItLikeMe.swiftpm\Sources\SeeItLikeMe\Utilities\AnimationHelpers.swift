import SwiftUI

struct AnimationHelpers {
    static let smooth = Animation.smooth(duration: 0.5)
    static let spring = Animation.spring(response: 0.3, dampingFraction: 0.7)
    static let easeInOut = Animation.easeInOut(duration: 0.3)
}