import SwiftUI

@main
struct SeeItLikeMeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}