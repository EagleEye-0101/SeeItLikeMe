import Foundation

enum AppPhase {
    case intro
    case selection
    case experience
    case finalReflection
}