import SwiftUI

struct FocusTunnelView: View {
    let onComplete: () -> Void
    @State private var isFocused = false
    @State private var centerText = ""
    @State private var peripheralTexts: [String] = []
    @State private var timerProgress: CGFloat = 0
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Focus Tunnel")
                .font(.largeTitle.weight(.semibold))
                .foregroundStyle(.primary)
            
            Text("Notice what you can see in your peripheral vision")
                .font(.title2)
                .foregroundStyle(.secondary)
            
            ZStack {
                // Peripheral texts (appear when not focused)
                if !isFocused {
                    ForEach(peripheralTexts.indices, id: \.self) { index in
                        Text(peripheralTexts[index])
                            .font(.headline)
                            .foregroundStyle(.secondary)
                            .position(getPeripheralPosition(for: index))
                    }
                }
                
                // Center focus area
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color.gray.opacity(0.1))
                    .frame(width: 200, height: 200)
                    .overlay(
                        Text(centerText)
                            .font(.largeTitle.weight(.bold))
                            .foregroundStyle(.primary)
                            .multilineTextAlignment(.center)
                            .padding()
                    )
                    .onTapGesture {
                        withAnimation(.spring(response: 0.3)) {
                            isFocused.toggle()
                        }
                    }
            }
            .frame(height: 350)
            
            VStack(spacing: 16) {
                if isFocused {
                    Text("Tapped! Notice what disappeared from your peripheral vision")
                        .font(.callout)
                        .foregroundStyle(.orange)
                        .multilineTextAlignment(.center)
                } else {
                    Text("Tap the center area to focus")
                        .font(.callout)
                        .foregroundStyle(.tertiary)
                }
                
                Text("This demonstrates how attention creates 'tunnels' in our vision")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding()
            
            Spacer()
            
            ProgressView(value: timerProgress, total: 1.0)
                .progressViewStyle(LinearProgressViewStyle())
                .padding(.horizontal)
            
            PrimaryButton(title: "Continue", action: onComplete)
                .padding(.bottom)
        }
        .padding()
        .onAppear {
            setupTexts()
            startTimer()
        }
        .onDisappear {
            timerProgress = 0
        }
    }
    
    private func setupTexts() {
        centerText = "FOCUS"
        peripheralTexts = [
            "HELLO",
            "WORLD",
            "DESIGN",
            "ACCESSIBILITY",
            "EMPATHY",
            "UX",
            "INTERFACE",
            "HUMAN"
        ]
    }
    
    private func getPeripheralPosition(for index: Int) -> CGPoint {
        let positions: [CGPoint] = [
            CGPoint(x: 80, y: 80),
            CGPoint(x: 270, y: 80),
            CGPoint(x: 80, y: 150),
            CGPoint(x: 270, y: 150),
            CGPoint(x: 80, y: 220),
            CGPoint(x: 270, y: 220),
            CGPoint(x: 80, y: 290),
            CGPoint(x: 270, y: 290)
        ]
        return positions[min(index, positions.count - 1)]
    }
    
    private func startTimer() {
        Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { timer in
            guard timerProgress < 1.0 else {
                timer.invalidate()
                return
            }
            timerProgress += 0.01
        }
    }
}