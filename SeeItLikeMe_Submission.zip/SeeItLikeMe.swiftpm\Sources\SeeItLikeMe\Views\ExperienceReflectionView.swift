import SwiftUI

struct ExperienceReflectionView: View {
    let experience: ExperienceType
    let onExit: () -> Void
    
    var body: some View {
        ScrollView {
            VStack(spacing: 32) {
                Spacer()
                    .frame(height: 40)
                
                Image(systemName: "lightbulb")
                    .font(.system(size: 60, weight: .thin))
                    .foregroundStyle(.primary)
                
                VStack(spacing: 24) {
                    Text("Reflection")
                        .font(.largeTitle.weight(.semibold))
                        .foregroundStyle(.primary)
                    
                    Text(reflectionText)
                        .font(.body)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
                
                Spacer()
                
                PrimaryButton(title: "Return to Selection", action: onExit)
                    .padding(.bottom)
            }
            .padding()
        }
    }
    
    private var reflectionText: String {
        switch experience {
        case .visualStrain:
            return "Small text and low contrast can cause eye strain and fatigue. Clear typography and sufficient contrast help everyone read comfortably for longer periods."
            
        case .readingStability:
            return "Moving or flickering content can be distracting and difficult to follow. Stable, predictable interfaces allow users to focus on their tasks without visual disruption."
            
        case .focusDistraction:
            return "Busy layouts with too many elements compete for attention. Clean, focused designs help users concentrate on what matters most."
            
        case .interactionPrecision:
            return "Tiny touch targets and complex gestures exclude many users. Generous sizing and simple interactions make interfaces usable by everyone."
            
        case .focusTunnel:
            return "Narrow attention tunnels limit peripheral awareness. Interfaces that support broader attention help users notice important information and navigate more confidently."
            
        case .colorPerception:
            return "Relying solely on color to convey meaning excludes users with color vision differences. Combining color with shapes, icons, or text ensures information is accessible to all."
        }
    }
}