import SwiftUI

struct ReadingStabilityView: View {
    let onComplete: () -> Void
    @State private var isShaking = false
    @State private var isFlickering = false
    @State private var timerProgress: CGFloat = 0
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Reading Stability")
                .font(.largeTitle.weight(.semibold))
                .foregroundStyle(.primary)
            
            Text("Try to read while content moves")
                .font(.title2)
                .foregroundStyle(.secondary)
            
            VStack(spacing: 25) {
                // Shaking text
                Text("This text is shaking")
                    .font(.title)
                    .fontWeight(.medium)
                    .offset(x: isShaking ? sin(Double(timerProgress) * 20) * 5 : 0)
                    .animation(isShaking ? .linear(duration: 0.1).repeatForever(autoreverses: false) : .default, value: timerProgress)
                
                // Flickering text
                Text("This text flickers")
                    .font(.title)
                    .fontWeight(.medium)
                    .opacity(isFlickering ? (sin(Double(timerProgress) * 30) > 0 ? 1.0 : 0.3) : 1.0)
                    .animation(isFlickering ? .linear(duration: 0.1).repeatForever(autoreverses: false) : .default, value: timerProgress)
            }
            .frame(maxWidth: .infinity)
            .padding()
            
            VStack(spacing: 12) {
                Toggle("Enable Shaking", isOn: $isShaking)
                    .toggleStyle(SwitchToggleStyle())
                
                Toggle("Enable Flickering", isOn: $isFlickering)
                    .toggleStyle(SwitchToggleStyle())
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(12)
            
            Text("Notice how movement affects readability")
                .font(.callout)
                .foregroundStyle(.tertiary)
            
            Spacer()
            
            ProgressView(value: timerProgress, total: 1.0)
                .progressViewStyle(LinearProgressViewStyle())
                .padding(.horizontal)
            
            PrimaryButton(title: "Continue", action: onComplete)
                .padding(.bottom)
        }
        .padding()
        .onAppear {
            startTimer()
        }
        .onDisappear {
            timerProgress = 0
        }
    }
    
    private func startTimer() {
        Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { timer in
            guard timerProgress < 1.0 else {
                timer.invalidate()
                return
            }
            timerProgress += 0.01
        }
    }
}