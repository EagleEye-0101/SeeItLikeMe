import SwiftUI

struct InteractionPrecisionView: View {
    let onComplete: () -> Void
    @State private var tapCount = 0
    @State private var successCount = 0
    @State private var timerProgress: CGFloat = 0
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Interaction Precision")
                .font(.largeTitle.weight(.semibold))
                .foregroundStyle(.primary)
            
            Text("Tap the small targets accurately")
                .font(.title2)
                .foregroundStyle(.secondary)
            
            ZStack {
                // Background grid for reference
                ForEach(0..<5) { row in
                    ForEach(0..<4) { col in
                        Rectangle()
                            .fill(Color.gray.opacity(0.05))
                            .frame(width: 70, height: 70)
                            .border(Color.gray.opacity(0.2), width: 0.5)
                    }
                }
                .position(x: 175, y: 175)
                
                // Small touch targets
                ForEach(targets) { target in
                    Circle()
                        .fill(target.isHit ? Color.green : Color.red)
                        .frame(width: target.size, height: target.size)
                        .position(target.position)
                        .onTapGesture {
                            handleTargetTap(id: target.id)
                        }
                }
            }
            .frame(height: 350)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(16)
            
            VStack(spacing: 12) {
                Text("Targets hit: \(successCount)/\(tapCount)")
                    .font(.headline)
                    .foregroundStyle(.primary)
                
                Text("Notice how target size affects accuracy")
                    .font(.callout)
                    .foregroundStyle(.tertiary)
            }
            .padding()
            
            Spacer()
            
            ProgressView(value: timerProgress, total: 1.0)
                .progressViewStyle(LinearProgressViewStyle())
                .padding(.horizontal)
            
            PrimaryButton(title: "Continue", action: onComplete)
                .padding(.bottom)
        }
        .padding()
        .onAppear {
            startTimer()
        }
        .onDisappear {
            timerProgress = 0
        }
    }
    
    private func handleTargetTap(id: UUID) {
        tapCount += 1
        
        if let index = targets.firstIndex(where: { $0.id == id }),
           targets[index].size >= 30 { // Minimum accessible size
            successCount += 1
            targets[index].isHit = true
        }
    }
    
    private func startTimer() {
        Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { timer in
            guard timerProgress < 1.0 else {
                timer.invalidate()
                return
            }
            timerProgress += 0.01
        }
    }
    
    @State private var targets: [Target] = [
        Target(id: UUID(), position: CGPoint(x: 100, y: 100), size: 20),
        Target(id: UUID(), position: CGPoint(x: 250, y: 120), size: 40),
        Target(id: UUID(), position: CGPoint(x: 180, y: 200), size: 15),
        Target(id: UUID(), position: CGPoint(x: 120, y: 280), size: 35),
        Target(id: UUID(), position: CGPoint(x: 280, y: 250), size: 25)
    ]
}

struct Target: Identifiable {
    let id: UUID
    let position: CGPoint
    let size: CGFloat
    var isHit = false
}