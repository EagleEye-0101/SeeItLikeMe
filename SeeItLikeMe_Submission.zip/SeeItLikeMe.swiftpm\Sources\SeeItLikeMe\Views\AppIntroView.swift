import SwiftUI

struct AppIntroView: View {
    let onStart: () -> Void
    
    var body: some View {
        VStack(spacing: 32) {
            Spacer()
            
            Image(systemName: "eyeglasses")
                .font(.system(size: 80, weight: .thin))
                .foregroundStyle(.primary)
            
            VStack(spacing: 16) {
                Text("See It Like Me")
                    .font(.largeTitle.weight(.semibold))
                    .foregroundStyle(.primary)
                
                Text("Understanding how interface design affects everyone")
                    .font(.title3)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            
            Spacer()
            
            PrimaryButton(title: "Begin Experience", action: onStart)
                .padding(.bottom)
        }
        .padding()
    }
}